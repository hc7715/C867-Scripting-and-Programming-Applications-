#pragma once


enum DegreeProgram {SECURITY,NETWORK,SOFTWARE,NONE};

//print enum to use in switch statement in print function
enum printAttributeType { pStudentID, pFirstName, pLastName, pEmail, pAge, pDays, pDegree, pAll }; //p used so program doesnt get confused from private class variables