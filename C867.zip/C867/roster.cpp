#include <iostream>
#include <string>
#include <vector>
#include <regex>

using namespace std;

#include "degree.h"
#include "student.h"
#include "roster.h"

//roster size
int Roster::rosterSize() {
	return rosterArray.size();
}


//add and remove functions
void Roster::add(string studentID, string firstName, string lastName, string email, int age, int day1, int day2, int day3, DegreeProgram degree) {
	int daysLeft[3] = { day1, day2, day3 };
	int* pDaysLeft = daysLeft;

	rosterArray.push_back(new Student(studentID, firstName, lastName, email, age, pDaysLeft, degree));
}


void Roster::remove(string studentID) {
	bool success = false;
	for (int i = 0; i < rosterArray.size(); i++) {
		if (rosterArray[i]->getStudentID() == studentID) {
			rosterArray.erase(rosterArray.begin() + i);
			cout << "Removed Student " << studentID << endl;
			success = true;
			break;
		}
	}
	if (success == false) {
		cout << "Did not find matching Student ID" << endl;
	}
}

//print functions
void Roster::printAll() {
	printAttributeType a = pAll;
	cout << "Roster Size: " << rosterArray.size() << endl;
	for (int i = 0; i < rosterArray.size(); i++) {
		rosterArray[i]->print(a);
		cout << "." << endl;
	}
}

void Roster::printAverageDaysInCourse(string studentID) {
	bool success = false;
	for (int i = 0; i < rosterArray.size(); i++) {
		if (rosterArray[i]->getStudentID() == studentID) {
			int* tempArray = rosterArray[i]->getDays();
			double average = 0;
			cout << "Average Days in Course for " << rosterArray[i]->getStudentID() << " " << rosterArray[i]->getFirstName() << " "
				<< rosterArray[i]->getLastName() << ": ";
			for (int j = 0; j < 3; j++) {
				average = average + tempArray[j];
			}
			average = average / 3;
			cout << average << endl;
			success = true;
			break;
		}
	}
	if (success = false) {
		cout << "Did not find matching Student ID" << endl;
	}
}

void Roster::printByDegreeProgram(DegreeProgram degree) {
	printAttributeType a = pAll;
	cout << "Students studying this degree: \n";
	for (int i = 0; i < rosterArray.size(); i++) {
		if (rosterArray[i]->getDegree() == degree) {
			rosterArray[i]->print(a);
			cout << "\n";
		}
	}
	cout << "\n";
}

void Roster::printInvalidEmails() {
	//regex email format
	const regex emailFormat("(\\w+)(\\.|_)?(\\w*)@(\\w+)(\\.(\\w+))+");

	cout << "Invaldi Emails: ";
	for (int i = 0; i < rosterArray.size(); i++) {
		if ((regex_match(rosterArray[i]->getEmail(), emailFormat)) == false) {
			cout << rosterArray[i]->getEmail() << "\t";
		}
	}
	cout << "\n";
}

//constructor function
Roster::Roster() {
}

//destructor function
Roster::~Roster() {
	cout << "Roster destructor activated" << endl;
}